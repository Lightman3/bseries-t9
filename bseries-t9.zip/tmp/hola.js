@Entity
public class EmailMessage extends AbstractTimestampEntity {

  @Id
  @GeneratedValue()
  private int id;

  @Column(length=ADDRESS_LIST_MAX_LENGTH,nullable=false,name="`to`")
  private String to;
  @Column(length=ADDRESS_LIST_MAX_LENGTH,nullable=false)
  private String cc;
  @Column(length=ADDRESS_LIST_MAX_LENGTH,nullable=false)
  private String bcc;

  @Column(length=SUBJECT_MAX_LENGTH,name="`subject`")
  private String subject;

  @Column(length=CONTENT_MAX_LENGTH,nullable=false)
  private String content;

  /** Constructor por defecto para hibernate */
  public EmailMessage() {
  }
  public int getId() {
    return id;
  }
  public String getTo() {
    return to;
  }
  public void setTo(String to) throws MessageSizeExceededException {
    // ...
  }
  public String getCc() {
    return cc;
  }
}